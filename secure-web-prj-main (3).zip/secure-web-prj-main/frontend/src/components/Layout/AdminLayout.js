import React from "react";
import Dashboard from "../admin/Dashboard.jsx";

const AdminLayout = () => {

  return (
    <Dashboard></Dashboard>
  );
};

export default AdminLayout;